//
// Created by Han Tran on 8/25/18.
//

#ifndef HW6
#define HW6

#include <mpi.h>

int matmul(double* A, double* B, double* C, unsigned long int m, unsigned long int k, unsigned long int n);

#endif